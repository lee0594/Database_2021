#include <stdio.h>
#include "mysql.h"

#pragma comment(lib, "libmysql.lib")

const char* host = "localhost";
const char* user = "student";
const char* pw = "shdwkd8522!";
const char* db = "project2";

int main(void) {

	MYSQL* connection = NULL;
	MYSQL conn;
	MYSQL_RES* sql_result;
	MYSQL_ROW sql_row;

	FILE* fp = fopen("20190594_1.txt", "r");
	

	if (mysql_init(&conn) == NULL)
		printf("mysql_init() error!");

	connection = mysql_real_connect(&conn, host, user, pw, db, 3306, (const char*)NULL, 0);
	if (connection == NULL)
	{
		printf("%d ERROR : %s\n", mysql_errno(&conn), mysql_error(&conn));
		return 1;
	}

	else
	{
		printf("Connection Succeed\n");

		if (mysql_select_db(&conn, db))
		{
			printf("%d ERROR : %s\n", mysql_errno(&conn), mysql_error(&conn));
			return 1;
		}

		printf("------- SELECT QUERY TYPES -------\n\n");
		printf("\t1. TYPE 1\n");
		printf("\t2. TYPE 2\n");
		printf("\t3. TYPE 3\n");
		printf("\t4. TYPE 4\n");
		printf("\t5. TYPE 5\n");
		printf("\t6. TYPE 6\n");
		printf("\t7. TYPE 7\n");
		printf("\t0. QUIT\n");
		//printf("----------------------------------\n");
		printf("\n\n");

		int choose;
		int select;
		char b_name[10];
		int k, count;
		int theyear[4];

		while (1)
		{
			printf("select number: ");
			scanf("%d", &choose);
			if (choose == 7)
				break;
			switch (choose) {
			case 1:
				printf("---- TYPE 1 ----\n\n");
				printf("Choose brand name and K : ");
				scanf("%s %d", b_name, &k); //type 1

				const char* query1 = "select sold_year,VIN,gender,annual_income from vehicle,customer where vehicle.brand_name= b_name and vehicle.sold_year between 2021-k and 2020";
				int state = 0;

				state = mysql_query(connection, query1);
				if (state == 0)
				{
					sql_result = mysql_store_result(connection);

					printf("%-10s %-10s %-10s %-10s", "year", "VIN", "gender", "annual_income");
					while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
					{
						printf("%-10s %-10s %-10s %s\n", sql_row[0], sql_row[1], sql_row[2], sql_row[3]);
					}

					//const char* query = "select * from query order by annual_income desc";

					mysql_free_result(sql_result);
				}
				
				printf("----------------Subtypes in TYPE 1----------------------");
				printf("\t1. TYPE 1-1\n");
				printf("\t2. TYPE 1-1-1\n");
				scanf("%d", &select);
				switch (select) {
				case 1:
					const char* query1_1 = "select sold_year,VIN,gender,annual_income from vehicle,customer where vehicle.brand_name= b_name and vehicle.sold_year between 2021-k and 2020 order by gender desc";
					int state = 0;

					state = mysql_query(connection, query1_1);
					if (state == 0)
					{
						sql_result = mysql_store_result(connection);

						printf("%-10s %-10s %-10s %-10s", "year", "VIN", "gender", "annual_income");
						while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
						{
							printf("%-10s %-10s %-10s %-10s\n", sql_row[0], sql_row[1], sql_row[2], sql_row[3]);
						}
						mysql_free_result(sql_result);
					}
					break;
				case 2:
					const char* query1_2 = "select sold_year,VIN,gender,annual_income from vehicle,customer where vehicle.brand_name= b_name and vehicle.sold_year between 2021-k and 2020 order by annual_income desc";
					int state = 0;

					state = mysql_query(connection, query1_2);
					if (state == 0)
					{
						sql_result = mysql_store_result(connection);

						printf("%-10s %-10s %-10s %-10s", "year", "VIN", "gender", "annual_income");
						while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
						{
							printf("%-10s %-10s %-10s %-10s\n", sql_row[0], sql_row[1], sql_row[2], sql_row[3]);
						}
						mysql_free_result(sql_result);
					}
					break;
				}
				break;
			case 2:
				printf("---- TYPE 2 ----\n\n");
				scanf("%s %d", b_name, &k); //type 2

				const char* query2 = "select brand_name,buy_date,VIN,gender,annual_income from brand,customer where vehicle.buy_date between 20210614-100*k and 20210614";
				int state = 0;

				state = mysql_query(connection, query2);
				if (state == 0)
				{
					sql_result = mysql_store_result(connection);

					printf("%-10s %-10s %-10s %-10s %-10s", "brand_name", "buy_date", "VIN", "gender", "annual_income");
					while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
					{
						printf("%-10s %-10s %-10s %-10s %-10s\n", sql_row[0], sql_row[1], sql_row[2], sql_row[3]);
					}

					//const char* query = "select * from query order by annual_income desc";

					mysql_free_result(sql_result);
				}
				printf("----------------Subtypes in TYPE 2----------------------");
				printf("\t1. TYPE 2-1\n");
				printf("\t2. TYPE 2-1-1\n");
				scanf("%d", &select);
				switch (select) {
				case 1:
					const char* query2_1 = "select brand_name,buy_date,VIN,gender,annual_income from brand,customer where vehicle.buy_date between 20210614-100*k and 20210614 order by gender desc";
					int state = 0;

					state = mysql_query(connection, query2_1);
					if (state == 0)
					{
						sql_result = mysql_store_result(connection);

						printf("%-10s %-10s %-10s %-10s %-10s", "brand_name", "buy_date", "VIN", "gender", "annual_income");
						while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
						{
							printf("%-10s %-10s %-10s %-10s %-10s\n", sql_row[0], sql_row[1], sql_row[2], sql_row[3]);
						}
						mysql_free_result(sql_result);
					}
					break;
				case 2:
					const char* query2_2 = "select brand_name,buy_date,VIN,gender,annual_income from brand,customer where vehicle.buy_date between 20210614-100*k and 20210614 order by annual_income desc";
					int state = 0;

					state = mysql_query(connection, query2_2);
					if (state == 0)
					{
						sql_result = mysql_store_result(connection);

						printf(" % -10s % -10s % -10s % -10s % -10s", "brand_name", "buy_date", "VIN", "gender", "annual_income");
						while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
						{
							printf("%-10s %-10s %-10s %-10s %-10s\n", sql_row[0], sql_row[1], sql_row[2], sql_row[3]);
						}
						mysql_free_result(sql_result);
					}
					break;
				}
				break;
			case 3:
				printf("---- TYPE 3 ----\n\n");
				break;
			case 4:
				printf("---- TYPE 4 ----\n\n");
				printf("**Find the top k brands by dollar - amount sold by the year **\n");
				printf("Choose year and K : ");
				scanf("%d %d", theyear, &k);	//type4
				count = 0;
				const char* query4 = "select brand_name, dollar_sold from brand where sold_year = theyear order by dollar_sold desc";
				int state = 0;

				state = mysql_query(connection, query4);
				if (state == 0)
				{
					sql_result = mysql_store_result(connection);

					printf("%-10s %-10s", "brand_name", "dollar_sold");
					while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
					{
						printf("%-10s %-10s\n", sql_row[0], sql_row[1]);
						count++;
						if (count == k)
							break;
					}
					mysql_free_result(sql_result);
				}
				break;
			case 5:
				printf("---- TYPE 5 ----\n\n");
				printf(" **Find the top k brands by unit sales by the year * *\n");
				printf("Choose year and K : ");
				scanf("%d %d", theyear, &k);	//type5
				const char* query5 = "select brand_name, sales from brand where sold_year = theyear order by sales desc";
				int state = 0;

				state = mysql_query(connection, query5);
				if (state == 0)
				{
					sql_result = mysql_store_result(connection);

					printf("%-10s %-10s", "brand_name", "sales");
					count = 0;
					while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
					{
						printf("%-10s %-10s\n", sql_row[0], sql_row[1]);
						count++;
						if (count == k)
							break;
					}
					mysql_free_result(sql_result);
				}
				break;
			case 6:
				printf("---- TYPE 6 ----\n\n");
				break;
			case 7:
				printf("---- TYPE 7 ----\n\n");
				break;
			}


			/*

			//type6
			const char* query6 = "select buy_date from vehicle where body_styles = convert";
			int state = 0;

			state = mysql_query(connection, query6);
			if (state == 0)
			{
				sql_result = mysql_store_result(connection);


				int j=0, f=0, m=0, a=0, m=0, j=0, jl=0, a=0, s=0, o=0, n=0, d=0;
				while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
				{
					printf("%s %s\n", sql_row[0], sql_row[1]);
					count++;
					if (count == k)
						break;
				}
				mysql_free_result(sql_result);
			}*/

		}
		
		FILE* fq = fopen("20190594_2.txt", "r");
		fclose(fp);
		fclose(fq);
		mysql_close(connection);
	}

	return 0;
}
